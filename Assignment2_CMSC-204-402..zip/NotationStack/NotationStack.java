import java.util.ArrayList;
class NotationStack<T> implements StackInterface<T>{
  private int defaultSize = 100;
  private T[] stack;
  private int sizeStack;
  private int lastElement;
  NotationStack(){
    stack = (T[]) new Object[defaultSize];
    sizeStack = defaultSize;
    lastElement = 0;
  }
  NotationStack(int s){
    stack = (T[]) new Object[s];
    sizeStack = s;
  }
  public boolean isEmpty(){
    if (lastElement == 0) {
      return true;
    }
    else {
      return false;
    }
  }
  public boolean isFull(){
    if (lastElement == sizeStack) {
      return true;
    }
    else {
      return false;
    }
  }
  public T pop() throws StackUnderflowException {
    if (lastElement > 0) {
      return stack[--lastElement];
    }
    else {
      throw new StackUnderflowException("The stack is underflow");
    }
  }
  public T top() throws StackUnderflowException{
    if (lastElement > 0) {
      return stack[lastElement - 1];
    }
    else {
      throw new StackUnderflowException("The stack is underflow");
    }
  }
  public int size(){
      return sizeStack;
  }
  public boolean push(T e) throws StackOverflowException{
    if (lastElement < sizeStack) {
      stack[lastElement++] = e;
      return true;
    }
    else {
      throw new StackOverflowException("The stack is overflow");
    }
  }
  public String toString(){
    String ret = "";
     for (int i = 0; i < lastElement; i++){
       ret += stack[i];
     }
    return ret;
   }
  public String toString(String delimiter){
     String ret = "";
     for (int i = 0; i < lastElement; i++){
       ret += stack[i];
       if (i != lastElement - 1) {
         ret+= delimiter;
       }

     }
     return ret;
  }
  public void fill(ArrayList<T> list){
    for (T element: list){
      stack[lastElement++] = element;
    }
  }
}
