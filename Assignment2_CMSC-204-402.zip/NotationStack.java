/**
* This is the NotationStack class
*
*
* @author Fatima Mancia
*
*/
import java.util.ArrayList;
class NotationStack<T> implements StackInterface<T>{
  private int defaultSize = 100;
  private T[] stack;
  private int sizeStack;
  private int lastElement;
  NotationStack(){
    stack = (T[]) new Object[defaultSize];
    sizeStack = defaultSize;
    lastElement = 0;
  }
  NotationStack(int s){
    stack = (T[]) new Object[s];
    sizeStack = s;
    lastElement = 0;
  }
  /**
   * isEmpty looks if the stack is empty.
   * @return if it is empty true. If not false.
   *
   */
  public boolean isEmpty(){
    if (lastElement == 0) {
      return true;
    }
    else {
      return false;
    }
  }
  /**
   * isFull looks if the stack is full.
   * @return if it is full true. If not false.
   *
   */
  public boolean isFull(){
    if (lastElement == sizeStack) {
      return true;
    }
    else {
      return false;
    }
  }
  /**
   * pop eliminates the last element of the stack.
   * @return the new array list. If not thorws exception.
   *
   */
  public T pop() throws StackUnderflowException {
    if (lastElement > 0) {
      return stack[--lastElement];
    }
    else {
      throw new StackUnderflowException("The stack is underflow");
    }
  }
   /**
   * top looks if the last element is greater than 0.
   * @return the new array list. If not thorws exception.
   *
   */
  public T top() throws StackUnderflowException{
    if (lastElement > 0) {
      return stack[lastElement - 1];
    }
    else {
      throw new StackUnderflowException("The stack is underflow");
    }
  }
   /**
   * size looks the size of the stack,
   * @return last element.
   *
   */
  public int size(){
      return lastElement;
  }
  /**
   * push adds a new element to the stack.
   * @param e id the last element.
   * @return true if it adds something. If not throw the exception.
   *
   */
  public boolean push(T e) throws StackOverflowException{
    if (lastElement < sizeStack) {
      stack[lastElement++] = e;
      return true;
    }
    else {
      throw new StackOverflowException("The stack is overflow");
    }
  }
     /**
   * toString
   * @return ret the new values.
   *
   */
  public String toString(){
    String ret = "";
     for (int i = 0; i < lastElement; i++){
       ret += stack[i];
     }
    return ret;
   }
   /**
   * toString prints the value of the stack.
   * @param delimiter founds the delimiter.
   * @return ret the new values.
   *
   */
  public String toString(String delimiter){
     String ret = "";
     for (int i = 0; i < lastElement; i++){
       ret += stack[i];
       if (i != lastElement - 1) {
         ret+= delimiter;
       }

     }
     return ret;
  }
  public void fill(ArrayList<T> list){
    for (T element: list){
      try {
        push(element);
      }
      catch (Exception e) {

      }
    }
  }
}
