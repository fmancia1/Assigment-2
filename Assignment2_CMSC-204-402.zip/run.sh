#!/bin/sh

CP="junit-4.13.1.jar:hamcrest-core.jar:."

# Compiling

javac -cp $CP QueueInterface.java NotationQueue.java NotationQueueTest.java 
javac -cp $CP StackInterface.java NotationStack.java NotationStackTest.java 
javac -cp $CP StackInterface.java Notation.java NotationTest.java 

# Running
java -cp $CP org.junit.runner.JUnitCore NotationStackTest
java -cp $CP org.junit.runner.JUnitCore NotationQueueTest
java -cp $CP org.junit.runner.JUnitCore NotationTest