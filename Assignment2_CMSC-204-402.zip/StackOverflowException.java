/**
* This class extended from Exception. It is the class for my own Exception
* 
* 
* @author Fatima Mancia
* 
*/
public class StackOverflowException extends Exception{
  public StackOverflowException(String message){
    super(message);
  }
}