/**
* This class extended from Exception. It is the class for my own Exception
* 
* 
* @author Fatima Mancia
* 
*/
public class InvalidNotationFormatException extends Exception{
  public InvalidNotationFormatException(String message){
    super(message);
  }
}