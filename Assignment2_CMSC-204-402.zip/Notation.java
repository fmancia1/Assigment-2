class Notation {
  public static String convertInfixToPostfix(String exp)
    throws InvalidNotationFormatException {
    NotationQueue<Character> queue = new NotationQueue<Character>(exp.length());
    NotationStack<Character> stack = new NotationStack<Character>(exp.length());
    try {
      for (int i = 0; i < exp.length(); i++) {
        Character c = exp.charAt(i);    
        if (Character.isSpace(c))
          continue;
        else if (Character.isDigit(c))
          queue.enqueue(c);
        else if (c == '(')
          stack.push(c);
        else if (c == '+' || c == '-') {
          while (!stack.isEmpty()) {
            Character op = stack.top();
            if (op == '*' || op == '/')
              queue.enqueue(stack.pop());
            else 
              break;
          }
          stack.push(c);
        }
        else if (c == '*' || c == '/')
          stack.push(c);
        else if (c == ')') {
          boolean matched = false;
          while (!stack.isEmpty()) {
            Character op = stack.pop();
            if (op == '(') {
              matched = true;
              break;
            }
            else 
              queue.enqueue(op);
          }
          if (!matched)
            throw new InvalidNotationFormatException("Parenthesis does not match");
        }
        else 
          throw new InvalidNotationFormatException("Invalid symbol found");
      }
      while (!stack.isEmpty())
        queue.enqueue(stack.pop());
    }
    catch (Exception e) {
      throw new InvalidNotationFormatException("An error ocurred");
    }
    return queue.toString();
  }

  public static String convertPostfixToInfix(String exp)
    throws InvalidNotationFormatException {
    NotationStack<String> stack = new NotationStack<String>(exp.length());
    String ret = "";
    try {
      for (int i = 0; i < exp.length(); i++) {
        Character c = exp.charAt(i);
        if (Character.isSpace(c))
          continue;
        else if (Character.isDigit(c))
          stack.push(Character.toString(c));
        else if (c == '+' || c == '-' || c == '*' || c == '/') {
          if (stack.size() < 2)
            throw new InvalidNotationFormatException("Too few operands");
          String op2 = stack.pop();
          String op1 = stack.pop();
          String aux = "(" + op1 + Character.toString(c) + op2 + ")";
          stack.push(aux);
        }
        else 
          throw new InvalidNotationFormatException("Invalid symbol found");
      }
      if (stack.size() != 1)
        throw new InvalidNotationFormatException("Number of operators mismatch");
      ret = stack.toString();
    }
    catch (Exception e) {
      throw new InvalidNotationFormatException("An error ocurred");
    }
    return ret;
  }
  
  public static double evaluatePostfixExpression(String exp)
    throws InvalidNotationFormatException{
    NotationStack<Double> stack = new NotationStack<Double>(exp.length());
    double value = 0;
    try {
      for (int i = 0; i < exp.length(); i++) {
        Character c = exp.charAt(i);
        if (Character.isSpace(c))
          continue;
        else if (Character.isDigit(c))
          stack.push(new Double(Character.toString(c)));
        else if (c == '+' || c == '-' || c == '*' || c == '/') {
          if (stack.size() < 2)
            throw new InvalidNotationFormatException("Number of operands mismatch");
          Double y = stack.pop();
          Double x = stack.pop();
          Double z = 0.0;
          switch (c) {
            case '+':
              z = x + y;
              break;
            case '-':
              z = x - y;
              break;
            case '*':
              z = x * y;
              break;
            case '/':
              z = x / y;
              break;
          }
          stack.push(z);
        }
        else 
          throw new InvalidNotationFormatException("Invalid symbol found");
      }
      if (stack.size() != 1)
        throw new InvalidNotationFormatException("Number of operands mismatch");
      value = stack.pop();
    }
    catch (Exception e) {
      throw new InvalidNotationFormatException("Syntax error");
    }
    return value;
  }
}