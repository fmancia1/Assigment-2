/**
* This is the NotationQueue class
*
*
* @author Fatima Mancia
*
*/
import java.util.ArrayList;
class NotationQueue<T> implements QueueInterface<T> {
  private int defaultS = 100;
  private T[] queue;
  private int sizeQ;
  private int lastE;
  private int firstE;
  private int count;
  private int item = 0;
  NotationQueue(){
    queue = (T[]) new Object[defaultS];
    sizeQ = defaultS;
    firstE = 0;
    lastE = -1;
    count = 0;
  }
  NotationQueue(int s){
    queue = (T[]) new Object[s];
    sizeQ = s;
    firstE = 0;
    lastE = -1;
    count = 0;
    /**
	 * isEmpty looks if the queue is empty.
	 * @return if the queue is empty returns true. If not false.
	 *
	 */
  }
  public boolean isEmpty() {
    if (count == 0) {
      return true;
    }
    else {
      return false;
    }
  }
  /**
	 * isFull looks if the queue is full
	 * @return if the queue is full return true. If not false.
	 *
	 */
  public boolean isFull(){
  if (count == sizeQ) {
      return true;
    }
    else {
      return false;
    }
  }
  /**
	 * dequeue looks if the queue is underflow.
	 * @return val if the queue is not empty. If it is returns exception.
	 *
	 */
  public T dequeue() throws QueueUnderflowException{
      T val;
      if (!isEmpty()) {
        val = queue[firstE];
        firstE = (firstE + 1) % sizeQ;
        count--;
      return val;
    }
    else {
      throw new QueueUnderflowException("The queue is underflow");
    }
  }
  /**
	 * size looks at the size of the queue.
	 * @return count.
	 *
	 */
  public int size(){
    return count;
  }
  /**
	 * enqueue looks if the queue is overflow.
	 * @return true if the queue is not full. If it is return exception.
	 *
	 */
  public boolean enqueue(T e) throws QueueOverflowException{
    if (!isFull()) {
       lastE = (lastE + 1) % sizeQ;
        queue[lastE] = e;
        count++;
      return true;
    }
    else {
      throw new QueueOverflowException("The queue is overflow");
    }
  }
  /**
	 * toString prints the list of numbers.
	 * @return ret the new values added.
	 *
	 */
  public String toString(){
      String ret = "";
      int pos;
     for (int i = 0; i < count; i++){
       pos = (firstE + i) % sizeQ;
       ret += queue[pos];
     }
    return ret;
  }
/**
   * toString prints the value of the queue
   * @param delimiter founds the delimiter.
   * @return ret the new values.
   *
   */
  public String toString(String delimiter){
     String ret = "";
     int pos;
     for (int i = 0; i < count; i++){
       pos = (firstE + i) % sizeQ;
       ret += queue[pos];
       if (i != count - 1) {
         ret+= delimiter;
       }
     }
     return ret;
  }
  /**
   * fill creates the array list.
   * @param list where the values are saved.
   * 
   *
   */
  public void fill(ArrayList<T> list){
    for (T element: list){
      try {
        enqueue(element);
      }
      catch (Exception e) {
        
      }
    }
  }
}
