/**
* This class extended from Exception. It is the class for my own Exception
* 
* 
* @author Fatima Mancia
* 
*/
public class StackUnderflowException extends Exception{
  public StackUnderflowException(String message){
    super(message);
  }
}